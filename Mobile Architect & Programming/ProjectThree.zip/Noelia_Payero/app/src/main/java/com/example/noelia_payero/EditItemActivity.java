package com.example.noelia_payero;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    EditText editName, editQuantity, editMinQuantity, editDescription;
    Switch editStatus;
    Button saveButton, deleteButton, addImageButton, removeImageButton;
    ImageView itemImageView;
    DatabaseHelper dbHelper;
    SmsHelper smsHelper;
    int itemId;
    String currentImageUri = null;

    private final ActivityResultLauncher<String> selectImageLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    currentImageUri = uri.toString();
                    itemImageView.setImageURI(uri);
                    try {
                        // Request persistable permission to access URI across reboots
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        // Expected if URI is not from a DocumentProvider
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // Initialize UI components
        editName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editItemQuantity);
        editMinQuantity = findViewById(R.id.editItemMinQuantity);
        editDescription = findViewById(R.id.editItemDescription);
        editStatus = findViewById(R.id.editItemStatus);
        saveButton = findViewById(R.id.buttonSaveEdit);
        deleteButton = findViewById(R.id.buttonDeleteItem);
        addImageButton = findViewById(R.id.buttonAddImage);
        removeImageButton = findViewById(R.id.buttonRemoveImage);
        itemImageView = findViewById(R.id.imageItem);

        dbHelper = new DatabaseHelper(this);
        smsHelper = new SmsHelper(this);

        itemId = getIntent().getIntExtra("itemId", -1);
        if (itemId != -1) {
            InventoryItem item = dbHelper.getItem(itemId);
            if (item != null) {
                editName.setText(item.getName());
                editQuantity.setText(String.valueOf(item.getQuantity()));
                editMinQuantity.setText(String.valueOf(item.getMinQuantity()));
                editDescription.setText(item.getDescription());
                editStatus.setChecked(item.isActive());
                currentImageUri = item.getImageUri();
                if (currentImageUri != null && !currentImageUri.isEmpty()) {
                    itemImageView.setImageURI(Uri.parse(currentImageUri));
                }
            }
        }

        // Image selection logic
        addImageButton.setOnClickListener(v -> selectImageLauncher.launch("image/*"));

        removeImageButton.setOnClickListener(v -> {
            currentImageUri = null;
            itemImageView.setImageResource(android.R.drawable.ic_menu_gallery);
        });

        // Delete item logic
        deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure you want to delete this item?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        dbHelper.deleteItem(itemId);
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        // Save changes logic
        saveButton.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();
            String quantityStr = editQuantity.getText().toString().trim();
            String minQuantityStr = editMinQuantity.getText().toString().trim();
            String description = editDescription.getText().toString().trim();
            boolean isActive = editStatus.isChecked();

            if (name.isEmpty() || quantityStr.isEmpty() || minQuantityStr.isEmpty()) {
                Toast.makeText(EditItemActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                int minQuantity = Integer.parseInt(minQuantityStr);

                InventoryItem updatedItem = new InventoryItem(itemId, name, quantity, minQuantity, description, isActive);
                updatedItem.setImageUri(currentImageUri);
                dbHelper.updateItem(updatedItem);

                // Trigger SMS Alert if inventory is low
                smsHelper.checkInventoryAndNotify(updatedItem);

                Toast.makeText(EditItemActivity.this, "Item updated", Toast.LENGTH_SHORT).show();
                finish();
            } catch (NumberFormatException e) {
                Toast.makeText(EditItemActivity.this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
