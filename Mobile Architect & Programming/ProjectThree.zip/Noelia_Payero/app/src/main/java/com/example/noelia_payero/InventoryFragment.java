package com.example.noelia_payero;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryFragment extends Fragment {

    RecyclerView dataRecyclerView;
    Button buttonAddData;
    DatabaseHelper dbHelper;
    InventoryAdapter adapter;
    SmsHelper smsHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.database_grid, container, false);

        // Remove the SMS settings button from the layout if it exists as we now use bottom nav
        View smsBtn = view.findViewById(R.id.buttonSmsSettings);
        if (smsBtn != null) smsBtn.setVisibility(View.GONE);

        dataRecyclerView = view.findViewById(R.id.dataRecyclerView);
        buttonAddData = view.findViewById(R.id.buttonAddData);

        dbHelper = new DatabaseHelper(getContext());
        smsHelper = new SmsHelper(getContext());

        loadData();

        buttonAddData.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AddItemActivity.class);
            startActivity(intent);
        });

        return view;
    }

    private void loadData() {
        adapter = new InventoryAdapter(getContext(), dbHelper, smsHelper);
        dataRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        dataRecyclerView.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }
}
