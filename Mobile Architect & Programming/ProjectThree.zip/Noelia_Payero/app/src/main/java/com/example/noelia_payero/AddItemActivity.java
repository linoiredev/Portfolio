package com.example.noelia_payero;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    EditText itemNameText, itemQuantityText, itemMinQuantityText, itemDescriptionText;
    Switch statusSwitch;
    Button addItemButton;
    DatabaseHelper dbHelper;
    SmsHelper smsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        itemNameText = findViewById(R.id.editItemName);
        itemQuantityText = findViewById(R.id.editItemQuantity);
        itemMinQuantityText = findViewById(R.id.editItemMinQuantity);
        itemDescriptionText = findViewById(R.id.editItemDescription);
        statusSwitch = findViewById(R.id.itemStatusSwitch);
        addItemButton = findViewById(R.id.buttonSaveItem);
        
        dbHelper = new DatabaseHelper(this);
        smsHelper = new SmsHelper(this);

        addItemButton.setOnClickListener(view -> {
            String name = itemNameText.getText().toString().trim();
            String quantityStr = itemQuantityText.getText().toString().trim();
            String minQuantityStr = itemMinQuantityText.getText().toString().trim();
            String description = itemDescriptionText.getText().toString().trim();

            if (name.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(AddItemActivity.this, "Please enter both name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                int minQuantity = minQuantityStr.isEmpty() ? 0 : Integer.parseInt(minQuantityStr);
                boolean isActive = statusSwitch.isChecked();

                long id = dbHelper.addItem(name, quantity, minQuantity, description, isActive ? 1 : 0);
                
                if (id != -1) {
                    InventoryItem newItem = new InventoryItem((int)id, name, quantity, minQuantity, description, isActive);
                    smsHelper.checkInventoryAndNotify(newItem);
                    
                    Toast.makeText(AddItemActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AddItemActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(AddItemActivity.this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
