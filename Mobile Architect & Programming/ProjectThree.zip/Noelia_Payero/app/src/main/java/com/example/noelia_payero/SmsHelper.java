package com.example.noelia_payero;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class SmsHelper {
    private static final String TAG = "SmsHelper";
    private Context context;

    public SmsHelper(Context context) {
        this.context = context;
    }

    public void checkInventoryAndNotify(InventoryItem item) {
        SharedPreferences prefs = context.getSharedPreferences("appPrefs", Context.MODE_PRIVATE);
        boolean prefAllowed = prefs.getBoolean("smsPermission", false);
        
        // Check actual system permission
        boolean systemAllowed = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        Log.d(TAG, "Checking inventory for: " + item.getName() + 
                " (Qty: " + item.getQuantity() + ", Min: " + item.getMinQuantity() + 
                ", Active: " + item.isActive() + ", Pref Allowed: " + prefAllowed + 
                ", System Allowed: " + systemAllowed + ")");

        // Notify if item is active and quantity is less than or equal to min quantity
        if (item.isActive() && item.getQuantity() <= item.getMinQuantity()) {
            String message = "Low Inventory Alert: " + item.getName() + " is at " + item.getQuantity() + 
                    " (Minimum: " + item.getMinQuantity() + ")";
            
            if (prefAllowed && systemAllowed) {
                try {
                    SmsManager smsManager;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        smsManager = context.getSystemService(SmsManager.class);
                    } else {
                        smsManager = SmsManager.getDefault();
                    }

                    if (smsManager != null) {
                        smsManager.sendTextMessage("5554", null, message, null, null);
                        Log.i(TAG, "SMS Sent successfully to 5554: " + message);
                        Toast.makeText(context, "SMS Alert Sent: " + message, Toast.LENGTH_LONG).show();
                    } else {
                        Log.e(TAG, "SmsManager is null");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to send SMS", e);
                    Toast.makeText(context, "SMS Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            } else if (prefAllowed && !systemAllowed) {
                Log.w(TAG, "SMS Pref is ON but System Permission is DENIED.");
                Toast.makeText(context, "Inventory Alert: SMS permission is missing in system settings.", Toast.LENGTH_LONG).show();
            } else {
                Log.w(TAG, "SMS Alert triggered but feature is disabled in app settings.");
                Toast.makeText(context, "Inventory Alert (SMS disabled): " + message, Toast.LENGTH_LONG).show();
            }
        }
    }
}
