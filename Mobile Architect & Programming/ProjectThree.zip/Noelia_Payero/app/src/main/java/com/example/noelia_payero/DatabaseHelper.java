package com.example.noelia_payero;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_db";
    private static final int DB_VERSION = 2; // Incrementing version to add image column

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "id";
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_MIN_QUANTITY = "min_quantity";
    public static final String COLUMN_ITEM_DESCRIPTION = "description";
    public static final String COLUMN_ITEM_STATUS = "status"; // 1=active,0=inactive
    public static final String COLUMN_ITEM_IMAGE = "image"; // Store image URI or Path as string

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USERNAME + " TEXT UNIQUE," +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        String createItems = "CREATE TABLE " + TABLE_ITEMS + "(" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_ITEM_NAME + " TEXT," +
                COLUMN_ITEM_QUANTITY + " INTEGER," +
                COLUMN_ITEM_MIN_QUANTITY + " INTEGER," +
                COLUMN_ITEM_DESCRIPTION + " TEXT," +
                COLUMN_ITEM_STATUS + " INTEGER DEFAULT 1," +
                COLUMN_ITEM_IMAGE + " TEXT)";
        db.execSQL(createItems);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_ITEMS + " ADD COLUMN " + COLUMN_ITEM_IMAGE + " TEXT");
        }
    }

    // Users
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Inventory Items
    public long addItem(String name, int quantity, int minQuantity, String description, int status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_MIN_QUANTITY, minQuantity);
        values.put(COLUMN_ITEM_DESCRIPTION, description != null ? description : "");
        values.put(COLUMN_ITEM_STATUS, status);
        return db.insert(TABLE_ITEMS, null, values);
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, null, null, null, null, null, COLUMN_ITEM_NAME);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
                int minQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_MIN_QUANTITY));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION));
                int status = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_STATUS));
                String image = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_IMAGE));
                InventoryItem item = new InventoryItem(id, name, quantity, minQuantity, description, status == 1);
                item.setImageUri(image);
                list.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public void updateItem(InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_QUANTITY, item.getQuantity());
        values.put(COLUMN_ITEM_MIN_QUANTITY, item.getMinQuantity());
        values.put(COLUMN_ITEM_DESCRIPTION, item.getDescription());
        values.put(COLUMN_ITEM_STATUS, item.isActive() ? 1 : 0);
        values.put(COLUMN_ITEM_IMAGE, item.getImageUri());
        db.update(TABLE_ITEMS, values, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(item.getId())});
    }

    public void deleteItem(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    public InventoryItem getItem(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, null, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
            int minQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_MIN_QUANTITY));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION));
            int status = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_STATUS));
            String image = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_IMAGE));
            cursor.close();
            InventoryItem item = new InventoryItem(id, name, quantity, minQuantity, description, status == 1);
            item.setImageUri(image);
            return item;
        }
        return null;
    }
}
