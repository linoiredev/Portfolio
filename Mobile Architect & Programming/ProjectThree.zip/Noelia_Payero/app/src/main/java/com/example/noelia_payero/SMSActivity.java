package com.example.noelia_payero;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final String TAG = "SMSActivity";
    Button allowButton, denyButton;
    Switch smsSwitch;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                Log.d(TAG, "SMS Permission Request Result: " + isGranted);
                updateUI(isGranted);
                if (isGranted) {
                    Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        allowButton = findViewById(R.id.buttonAllow);
        denyButton = findViewById(R.id.buttonDeny);
        smsSwitch = findViewById(R.id.smsToggle);

        // Current state based on actual system permission
        boolean currentPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        Log.d(TAG, "Current System SMS Permission: " + currentPermission);
        updateUI(currentPermission);

        allowButton.setOnClickListener(v -> {
            Log.d(TAG, "Allow Button Clicked");
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                updateUI(true);
                Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        denyButton.setOnClickListener(v -> {
            Log.d(TAG, "Deny Button Clicked");
            updateUI(false);
            Toast.makeText(this, "SMS alerts disabled in app settings.", Toast.LENGTH_SHORT).show();
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void updateUI(boolean allowed) {
        SharedPreferences prefs = getSharedPreferences("appPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("smsPermission", allowed).apply();
        
        if (smsSwitch != null) {
            smsSwitch.setChecked(allowed);
            smsSwitch.setText(allowed ? "Notifications On" : "Notifications Off");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
