package com.example.noelia_payero;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;
    private int minQuantity;
    private String description;
    private boolean isActive;
    private String imageUri;

    public InventoryItem(int id, String name, int quantity, int minQuantity, String description, boolean isActive) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.minQuantity = minQuantity;
        this.description = description;
        this.isActive = isActive;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public int getMinQuantity() { return minQuantity; }
    public String getDescription() { return description; }
    public boolean isActive() { return isActive; }
    public String getImageUri() { return imageUri; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setMinQuantity(int minQuantity) { this.minQuantity = minQuantity; }
    public void setDescription(String description) { this.description = description; }
    public void setActive(boolean active) { isActive = active; }
    public void setImageUri(String imageUri) { this.imageUri = imageUri; }
}
