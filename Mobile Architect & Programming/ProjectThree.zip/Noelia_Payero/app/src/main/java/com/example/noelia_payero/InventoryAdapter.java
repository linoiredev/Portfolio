package com.example.noelia_payero;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private Context context;
    private List<InventoryItem> itemList;
    private DatabaseHelper dbHelper;
    private SmsHelper smsHelper;

    public InventoryAdapter(Context context, DatabaseHelper dbHelper, SmsHelper smsHelper) {
        this.context = context;
        this.dbHelper = dbHelper;
        this.smsHelper = smsHelper;
        this.itemList = dbHelper.getAllItems();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.nameText.setText(item.getName());
        holder.quantityText.setText(String.valueOf(item.getQuantity()));
        holder.statusSwitch.setChecked(item.isActive());

        // Visual cue for low inventory
        if (item.isActive() && item.getQuantity() <= item.getMinQuantity()) {
            holder.quantityText.setTextColor(context.getResources().getColor(android.R.color.holo_red_dark));
        } else {
            holder.quantityText.setTextColor(context.getResources().getColor(android.R.color.black));
        }

        holder.statusSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setActive(isChecked);
            dbHelper.updateItem(item);
            if (isChecked) {
                smsHelper.checkInventoryAndNotify(item);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditItemActivity.class);
            intent.putExtra("itemId", item.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList != null ? itemList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, quantityText;
        Switch statusSwitch;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemName);
            quantityText = itemView.findViewById(R.id.itemQuantity);
            statusSwitch = itemView.findViewById(R.id.itemStatus);
        }
    }
}
