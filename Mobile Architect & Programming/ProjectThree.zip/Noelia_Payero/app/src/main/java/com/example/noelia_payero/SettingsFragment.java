package com.example.noelia_payero;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    Button allowButton, denyButton;
    Switch smsToggle;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updateUIState(isGranted);
                if (isGranted) {
                    Toast.makeText(getContext(), "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "SMS Permission Denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.sms, container, false);

        allowButton = view.findViewById(R.id.buttonAllow);
        denyButton = view.findViewById(R.id.buttonDeny);
        smsToggle = view.findViewById(R.id.smsToggle);

        // Sync UI with current system permission
        boolean currentPermission = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        updateUIState(currentPermission);

        allowButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                updateUIState(true);
                Toast.makeText(getContext(), "Permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        denyButton.setOnClickListener(v -> {
            updateUIState(false);
            Toast.makeText(getContext(), "SMS alerts disabled in app settings.", Toast.LENGTH_SHORT).show();
        });

        // The switch acts as a master toggle for the preference
        smsToggle.setOnClickListener(v -> {
            boolean isChecked = smsToggle.isChecked();
            if (isChecked) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                } else {
                    updateUIState(true);
                }
            } else {
                updateUIState(false);
            }
        });

        return view;
    }

    private void updateUIState(boolean allowed) {
        if (getActivity() == null) return;
        
        SharedPreferences prefs = getActivity().getSharedPreferences("appPrefs", Context.MODE_PRIVATE);
        prefs.edit().putBoolean("smsPermission", allowed).apply();
        
        if (smsToggle != null) {
            smsToggle.setChecked(allowed);
            smsToggle.setText(allowed ? "Notifications On" : "Notifications Off");
        }
    }
}
