package com.example.noelia_payero;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button loginButton, registerButton;
    TextView textGreeting;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editUsername = findViewById(R.id.nameText);
        editPassword = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        textGreeting = findViewById(R.id.loginTitle); // reuse title TextView for greeting
        dbHelper = new DatabaseHelper(this);

        // Login button click
        loginButton.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean validUser = dbHelper.checkUser(username, password);
            if (validUser) {
                // Show welcome message
                textGreeting.setText("Welcome " + username + "!");
                // Go to inventory screen after greeting
                Intent intent = new Intent(MainActivity.this, DatabaseGridActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "User not found. Please create an account.", Toast.LENGTH_SHORT).show();
                // Keep entered username/password so user can register easily
            }
        });

        // Register button click
        registerButton.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean added = dbHelper.addUser(username, password);
            if (added) {
                Toast.makeText(MainActivity.this, "Account created! Welcome " + username, Toast.LENGTH_SHORT).show();
                textGreeting.setText("Welcome " + username + "!");
                // Optionally go to inventory
                Intent intent = new Intent(MainActivity.this, DatabaseGridActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Username already exists. Choose another.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
